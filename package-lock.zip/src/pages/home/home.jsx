import React, { useContext, useEffect } from 'react';
import Table from '../../components/Table';
import { DataContext } from '../Layout'

function Home() {
    const { data } = useContext(DataContext)
    const { http } = useContext(DataContext)

    useEffect(() => {
        http.get('api/table')
            .then(res => {
                // Обработка успешного ответа
                console.log(res.data.items)
            })
            .catch(err => {
                // Обработка ошибки
                console.error(err);
            });
    }, [])

    return (
        <main>

            <div className="main_block">
                <div className="table_container">
                    {data['tables'] && data['tables'].map((item) => (

                        <Table itemProp={item} />

                    ))}
                </div>

            </div>

        </main>
    );
}

export default Home;