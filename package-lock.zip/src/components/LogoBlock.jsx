import React from 'react';
import Logo from './logo'

function LogoBlock(props) {
    return (
        <div>
            <img src="/logo.svg" alt="logo"/>
        </div>
    );
}

export default LogoBlock;